//CoursesPage.js
import React, {useState, useEffect} from "react";
import Header from "../components/Header.js";
import Footer from "../components/Footer.js"


  // Main Structure of CoursesPage.js
  const CoursesPage = () => {

    return (
      <div className="courses-page">
        <Header />
        <Footer />
      </div>
    );
  };
  
  export default CoursesPage;
  