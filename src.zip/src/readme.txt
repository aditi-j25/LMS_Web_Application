PROJECT DEPENDENCIES 
==================================

This project uses the following dependencies:

1. React (Version: 19.0.0)
   Installation: npm install react

2. React DOM (Version: 19.0.0)
   Installation: npm install react-dom

3. React Router DOM (Version: 7.4.0)
   Installation: npm install react-router-dom

4. React Scripts (Version: 5.0.1)
   Installation: npm install react-scripts

5. Web Vitals (Version: 2.1.4)
   Installation: npm install web-vitals

6. Testing Library - DOM (Version: 10.4.0)
   Installation: npm install @testing-library/dom

7. Testing Library - Jest DOM (Version: 6.6.3)
   Installation: npm install @testing-library/jest-dom

8. Testing Library - React (Version: 16.2.0)
   Installation: npm install @testing-library/react

9. Testing Library - User Event (Version: 13.5.0)
   Installation: npm install @testing-library/user-event

=========================================================
INSTALLATION COMMANDS 

To install individual dependencies, use:
    npm install react-router-dom

To update dependencies:
    npm update

To fix security vulnerabilities:
    npm audit fix 
    OR 
    npm audit fix --force 
-------------------------------------------------
