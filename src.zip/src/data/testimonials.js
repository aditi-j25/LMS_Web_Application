//TESTIMONIAL.JS

const testimonials = [
    {
        studentName: "Alice Johnson",
        courseName: "Web Development",
        review: "Excellent course structure!",
        rating: 5
    },
    {
        studentName: "Michael Smith",
        courseName: "Data Science",
        review: "Great hands-on projects and well-explained concepts!",
        rating: 4
    },
    {
        studentName: "Sophia Martinez",
        courseName: "Cybersecurity",
        review: "Very informative and practical. Highly recommended!",
        rating: 5
    },
    {
        studentName: "James Brown",
        courseName: "Machine Learning",
        review: "Challenging but rewarding. The instructor was fantastic!",
        rating: 3
    }
];

    export default testimonials;

