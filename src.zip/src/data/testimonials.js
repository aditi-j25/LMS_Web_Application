//TESTIMONIAL.JS

const testimonials = [
    {
    studentName: "Alice Johnson",
    courseName: "Web Development",
    review: "Excellent course structure!",
    rating: 5
    },
    // Add 3 more testimonials...
    ];
    export default testimonials;

