//COURSE.JS 
const courses = [
    {
        id: 1,
        name: "Web Development",
        instructor: "Dr. John Smith",
        description: "Master HTML, CSS, and JavaScript.",
        duration: "8 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 2,
        name: "Python for Beginners",
        instructor: "Prof. Alice Johnson",
        description: "Learn Python from scratch with hands-on projects.",
        duration: "6 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 3,
        name: "Data Structures & Algorithms",
        instructor: "Dr. Mark Wilson",
        description: "Understand essential data structures and algorithms.",
        duration: "10 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 4,
        name: "Machine Learning Basics",
        instructor: "Dr. Emily Davis",
        description: "Introduction to supervised and unsupervised learning.",
        duration: "12 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 5,
        name: "Cybersecurity Fundamentals",
        instructor: "Prof. Michael Brown",
        description: "Learn about network security and cryptography.",
        duration: "8 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 6,
        name: "Mobile App Development",
        instructor: "Dr. Sarah Lee",
        description: "Build iOS and Android apps using React Native.",
        duration: "10 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 7,
        name: "Cloud Computing",
        instructor: "Dr. David Martinez",
        description: "Explore AWS, Azure, and Google Cloud platforms.",
        duration: "9 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 8,
        name: "Blockchain and Cryptocurrency",
        instructor: "Prof. Olivia White",
        description: "Learn how blockchain technology powers cryptocurrencies.",
        duration: "7 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 9,
        name: "Artificial Intelligence",
        instructor: "Dr. Robert Green",
        description: "Understand AI concepts and their real-world applications.",
        duration: "10 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 10,
        name: "UI/UX Design",
        instructor: "Prof. Jessica Hall",
        description: "Master the principles of user experience and interface design.",
        duration: "6 weeks",
        image: "images/course1.jpg"
    }
];

    export default courses; 
