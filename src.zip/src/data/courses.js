//COURSE.JS 

const courses = [
    {
    id: 1,
    name: "Web Development",
    instructor: "Dr. John Smith",
    description: "Master HTML, CSS, and JavaScript.",
    duration: "8 weeks",
    image: "images/course1.jpg"
    },
    // Add 9 more courses...
    ];
    export default courses; 
