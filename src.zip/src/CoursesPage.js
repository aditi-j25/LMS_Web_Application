//CoursesPage.js
import React, {useState, useEffect} from "react";
import courses from "./data/courses.js"; 
import Header from "./components/Header.js";
import Footer from "./components/Footer.js"


// A. CourseItem Component function 
const CourseItem = ({ course, enrollCourse }) => {
    const [showDescription, setShowDescription] = useState(false);
  
    return (
      <div
        className="course-item"
        onMouseEnter={() => setShowDescription(true)}
        onMouseLeave={() => setShowDescription(false)}
      >
        <img src={course.image} alt={course.name} />
        <h3>{course.name}</h3>
        <p>Instructor: {course.instructor}</p>
        {showDescription && <p>{course.description}</p>}
        <button onClick={() => enrollCourse(course)}>Enroll Now</button>
      </div>
    );
  };
  
  // B. EnrolledCourse Component function 
  const EnrolledCourse = ({ course, dropCourse }) => {
    return (
      <div className="enrolled-course">
        <h4>{course.name}</h4>
        <p>Credit Hours: {course.creditHours}</p>
        <button onClick={() => dropCourse(course)}>Drop Course</button>
      </div>
    );
  };
  
  // C. EnrollmentList Component function
  const EnrollmentList = ({ enrolledCourses, setEnrolledCourses }) => {
    useEffect(() => {
      localStorage.setItem("enrolledCourses", JSON.stringify(enrolledCourses));
    }, [enrolledCourses]);
  
    const dropCourse = (course) => {
      const updatedCourses = enrolledCourses.filter((c) => c.name !== course.name);
      setEnrolledCourses(updatedCourses);
    };
  
    const totalCreditHours = enrolledCourses.reduce((sum, course) => sum + course.creditHours, 0);
  
    return (
      <div className="enrollment-list">
        <h2>Enrolled Courses</h2>
        {enrolledCourses.map((course) => (
          <EnrolledCourse key={course.name} course={course} dropCourse={dropCourse} />
        ))}
        <h3>Total Credit Hours: {totalCreditHours}</h3>
      </div>
    );
  };
  
  // D. CourseCatalog Component function 
  const CourseCatalog = ({ enrollCourse }) => {
    return (
      <div className="course-catalog">
        <h2>Course Catalog</h2>
        {courses.map((course) => (
          <CourseItem key={course.name} course={course} enrollCourse={enrollCourse} />
        ))}
      </div>
    );
  };
  

  // Main Structure of CoursesPage.js
  const CoursesPage = () => {
    const [enrolledCourses, setEnrolledCourses] = useState(() => {
      return JSON.parse(localStorage.getItem("enrolledCourses")) || [];
    });
  
    const enrollCourse = (course) => {
      if (!enrolledCourses.some((c) => c.name === course.name)) {
        setEnrolledCourses([...enrolledCourses, course]);
      }
    };
  
    return (
      <div className="courses-page">
        <Header />
        <div className="content">
          <CourseCatalog enrollCourse={enrollCourse} />
          <EnrollmentList enrolledCourses={enrolledCourses} setEnrolledCourses={setEnrolledCourses} />
        </div>
        <Footer />
      </div>
    );
  };
  
  export default CoursesPage;
  