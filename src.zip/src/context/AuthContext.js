import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    // Try loading user from localStorage at startup (i.e. if you've signed up)
    // Also ensures that if you are logged in and you refresh your data will still remain as is on the page
    const storedUser = localStorage.getItem('lms_user');
    return storedUser ? JSON.parse(storedUser) : null;
  });

  const login = (userData) => {
    setUser(userData);
    localStorage.setItem('lms_user', JSON.stringify(userData)); // Save to localStorage called by LoginForm to save info
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('lms_user'); // Clear from localStorage
  };

  const isLoggedIn = !!user;

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoggedIn }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
