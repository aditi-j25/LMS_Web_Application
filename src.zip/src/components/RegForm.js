import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

const RegForm = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  // Logic to connect to backend below
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent default response after submisson 
    setIsLoading(true);
    setError('');

    //Username validation
    const starting_username_allowed = /^[a-zA-Z]+$/; // Only letters allowed
    const username_allowed = /^[a-zA-Z0-9-_]+$/; // Only letters, numbers, hyphens and underscores allowed
   
    if (!starting_username_allowed.test(username[0])) {
        setError('Username must start with a letter');
        setIsLoading(false);
        return;
    }
    if (!username_allowed.test(username)) {
        setError('Username must not contain any special characters except for hyphens and underscores');
        setIsLoading(false);
        return;
    }    
    if ((username.length < 3) || (username.length > 20)) {
      setError('Username must be between 3 and 20 characters long');
      return;
    }

    // Password validation
    const password_allowed = /^[a-zA-Z0-9!@#$%^&*()_\-=\+\[\]{}|;:'",.<>?`~]+$/;
    if (!password_allowed.test(password)) {
        setError('Password must not contain any space or special characters except for !@#$%^&*()-_=+[]{}|;:\'",.<>?[/]`~');
        setIsLoading(false);
        return;
    }
    if (password.length < 8) {
        setError('Password must be at least 8 characters long');
        setIsLoading(false);
        return;
    }
    if (!/[a-zA-Z]/.test(password)) {
        setError('Password must contain at least one letter');
        setIsLoading(false);
        return;
    }
    if (!/[0-9]/.test(password)) {
        setError('Password must contain at least one number');
        setIsLoading(false);
        return;
    }      
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
        setError('Password must contain at least one special character');
        setIsLoading(false);
        return;
    }
      
    // Password confirmation validation
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      setIsLoading(false);
      return;
    }

    // Email validation
    const email_allowed = /^[a-zA-Z0-9-_]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,}$/; // Basic email format using regex
    if (!email.match(email_allowed)) {
        setError('Invalid email address format');
        setIsLoading(false);
        return;
    }
    if (!/\.(com|net|io)$/i.test(email)) {
        setError('Email must end with .com, .net, or .io');
        setIsLoading(false);
        return;
    }
      
    if(email.includes(' ')) {
        setError('Email must not contain any spaces');
        setIsLoading(false);
        return;
    }

    // Sending data to backend
    try {
      console.log('Sending register request with:', { username, password, email});
      
      const response = await fetch('http://localhost:5000/signup', { // Call to backend
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();
      console.log('SignUp response:', data);

      if (response.ok) {
        navigate('/login'); // Redirect
      } else {
        setError(data.message || 'Login failed');
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('Failed to connect to the server. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ width: '100%' }}>
      <div style={{ marginBottom: '15px' }}>
        <label htmlFor="username" style={{ display: 'block', marginBottom: '5px' }}>
          Username:
        </label>
        <input
          type="text"
          id="username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
          style={{ width: '100%', padding: '8px' }}
        />
      </div>

      <div style={{ marginBottom: '20px' }}>
        <label htmlFor="password" style={{ display: 'block', marginBottom: '5px' }}>
          Password:
        </label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={{ width: '100%', padding: '8px' }}
        />
      </div>

        
      <div style={{ marginBottom: '20px' }}>
        <label htmlFor="confirm_password" style={{ display: 'block', marginBottom: '5px' }}>
          Confirm Password:
        </label>
        <input
          type="password"
          id="confirm_password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
          style={{ width: '100%', padding: '8px' }}
        />
      </div>

      <div style={{ marginBottom: '20px' }}>
        <label htmlFor="email" style={{ display: 'block', marginBottom: '5px' }}>
          Email:
        </label>
        <input
          type="text"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={{ width: '100%', padding: '8px' }}
        />
      </div>

      {error && (
        <div style={{ 
          color: '#D32F2F', 
          backgroundColor: '#FFEBEE', 
          padding: '10px', 
          borderRadius: '4px',
          marginBottom: '15px'
        }}>
          {error}
        </div>
      )}

      <button 
        type="Signup" 
        disabled={isLoading}
        style={{
          width: '100%',
          padding: '10px',
          backgroundColor:'#4CAF50',
          color: 'white',
          borderRadius: '5px',
          margin: '10px',
          opacity:'0.5',
          cursor: isLoading ? 'not-allowed' : 'pointer',
          ':hover':{
            backgroundColor: '#45A049',
            opacity: '1'
          },
        }}
      >
        {isLoading ? 'Redirecting to the Login Page...' : 'Sign Up'}
      </button>
      
      <div style={{ 
        marginTop: '15px', 
        textAlign: 'center', 
        fontSize: '0.9rem' 
      }}>

      </div>
    </form>
  );
};

export default RegForm;