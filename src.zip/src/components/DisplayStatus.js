import '../components/styles.css';

function DisplayStatus({ type, message }) {
  return (
      <div className={type}> {/* Different styling for different class. Example: Red text for error message */}
          {message}
      </div>
  );
}

export default DisplayStatus;