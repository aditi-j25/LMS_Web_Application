// Homepage.js
import React from 'react';
import Header from './Header';
import Footer from './Footer';
import MainSection from './MainSection';

const Homepage = () => {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header />
      <MainSection />
      <Footer />
    </div>
  );
};

export default Homepage;
