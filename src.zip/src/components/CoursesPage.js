import React, { useState, useEffect } from 'react';
import Header from './Header';
import Footer from './Footer';
import CourseItem from './CourseItem';
import EnrollmentList from './EnrollmentList';
import { useAuth } from '../context/AuthContext';

const CoursesPage = () => {
  const [availableCourses, setAvailableCourses] = useState([]);
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user } = useAuth();

   // Logic to connect to backend below
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Fetch all available courses
        const coursesResponse = await fetch('http://localhost:5000/courses');
        const coursesData = await coursesResponse.json();
        setAvailableCourses(coursesData);

        // Fetchs student's enrolled courses if they are still logged in
        if (user && user.id) {
          const enrolledCoursesResponse = await fetch(`http://localhost:5000/student_courses/${user.id}`);
          const enrolledCoursesData = await enrolledCoursesResponse.json();
          setEnrolledCourses(enrolledCoursesData);
        }
      } catch (err) {
        setError('Failed to fetch courses. Please try again later.'); 
        console.error('Error fetching courses:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const handleEnroll = async (course) => {
    if (!user || !user.id) {
      alert('Please login to enroll in courses'); // In case no student is logged in
      return;
    }

    try {
      const response = await fetch(`http://localhost:5000/enroll/${user.id}`, { // Sends a POST request to /enroll/<user.id> with the full course object
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(course),
      });

      const data = await response.json();

      if (response.ok) {
        // Refresh enrolled courses
        const updatedCoursesResponse = await fetch(`http://localhost:5000/student_courses/${user.id}`);
        const updatedCoursesData = await updatedCoursesResponse.json();
        setEnrolledCourses(updatedCoursesData);
      } else {
        alert(data.message || 'Failed to enroll in course');
      }
    } catch (err) {
      alert('Server error. Please try again later.');
      console.error('Error enrolling in course:', err);
    }
  };

  const handleRemove = async (enrollmentId) => {
    if (!user || !user.id) {
      alert('Please login to drop courses');
      return;
    }

    try {
      // Find the course object with this enrollment ID
      const courseToRemove = enrolledCourses.find(course => course.enrollmentId === enrollmentId);
      
      if (!courseToRemove) {
        alert('Course not found');
        return;
      }

      const response = await fetch(`http://localhost:5000/drop/${user.id}`, {
        method: 'DELETE',                 // Sends a DELETE request to Flask backend
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ enrollmentId }),
      });   // Removes the course with that enrollment ID from students.json

      const data = await response.json();

      if (response.ok) {
        // If drop was successfu then it will refresh the enrollment list
        const updatedCoursesResponse = await fetch(`http://localhost:5000/student_courses/${user.id}`);
        const updatedCoursesData = await updatedCoursesResponse.json();
        setEnrolledCourses(updatedCoursesData);
      } else {
        alert(data.message || 'Failed to drop course');
      }
    } catch (err) {
      alert('Server error. Please try again later.');
      console.error('Error dropping course:', err);
    }
  };

  if (isLoading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
        <Header />
        <div style={{ flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <p>Loading courses...</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
        <Header />
        <div style={{ flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <p style={{ color: 'red' }}>{error}</p>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      flexDirection: 'column' 
    }}>
      <Header />
      
      <div style={{ 
        flex: 1,
        display: 'flex',
        padding: '20px',
        gap: '30px'
      }}>
        <div style={{ flex: 3 }}>
          <h2 style={{ color: '#004080' }}>Available Courses</h2>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
            gap: '20px'
          }}>
            {availableCourses.map(course => (
              <CourseItem 
                key={course.id} 
                course={course} 
                onEnroll={handleEnroll}
              />
            ))}
          </div>
        </div>
        
        <EnrollmentList 
          enrolledCourses={enrolledCourses}
          onRemove={handleRemove}
        />
      </div>

      <Footer />
    </div>
  );
};

export default CoursesPage;