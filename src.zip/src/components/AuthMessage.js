import React, { useContext } from 'react';
import { AuthContext } from './LoginForm'; 
import DisplayStatus from './DisplayStatus';
import '../components/styles.css';

function AuthMessage() {
  const { message, messageType } = useContext(AuthContext);  // From LoginForm

  return (
    <div>
      <DisplayStatus type={messageType} message={message} /> {/* Using props and calling DisplayStatus */}
    </div>
  );
}

export default AuthMessage;