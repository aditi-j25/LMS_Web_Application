import '../components/styles.css';


function Footer() {
    return(
        <div>
            <footer><p>&copy; 2025 LMS. All rights reserved.</p></footer>
        </div>
    )
}

export default Footer;