import React, { useState, useEffect } from 'react';
import courses from '../data/courses';
import testimonials from '../data/testimonials';
import courseImage from '../images/course1.jpg';
import '../components/styles.css'

function MainSection() { 
    const [randomCourse1, setRandomCourse1] = useState(null); // Set these values initially to null 
    const [randomCourse2, setRandomCourse2] = useState(null);
    const [randomCourse3, setRandomCourse3] = useState(null);
    const [randomTestimonial1, setRandomTestimonial1] = useState(null);
    const [randomTestimonial2, setRandomTestimonial2] = useState(null);
    useEffect(() => {
        console.log("Filled Stars:", '★'.repeat(randomTestimonial1?.rating || 0));
        console.log("Empty Stars:", '☆'.repeat(5 - (randomTestimonial1?.rating || 0)));
    }, [randomTestimonial1]);
    

    useEffect(() => {
        const course1 = courses[Math.floor(Math.random() * courses.length)];

          /* The above calculation works in the way where Math.random() randomly 
        selects a value in between 0-1. This number is then multiplied by the 
        number of elements/objects in the provided data. Then because the result
        can be a decimal number, the floor of it is taken. Thus providing a random
        index which selects the object of the data at that index. */

        let course2;
        do {
            course2 = courses[Math.floor(Math.random() * courses.length)];
        } while (course2 === course1);  // We do not want the courses to be the same

        let course3;
        do {
            course3 = courses[Math.floor(Math.random() * courses.length)];
        } while (course3 === course2 || course3 === course1);

        setRandomCourse1(course1);
        setRandomCourse2(course2);
        setRandomCourse3(course3);

        const testimonial1 = testimonials[Math.floor(Math.random() * testimonials.length)];
        let testimonial2;
        do {
            testimonial2 = testimonials[Math.floor(Math.random() * testimonials.length)];
        } while (testimonial2 === testimonial1);

        setRandomTestimonial1(testimonial1);
        setRandomTestimonial2(testimonial2);

    }, []);

    const featuredCourses = [];
    if (randomCourse1) featuredCourses.push(randomCourse1);    // To avoid pushing when the values are null
    if (randomCourse2) featuredCourses.push(randomCourse2);
    if (randomCourse3) featuredCourses.push(randomCourse3);

    const randomTestimonials = [];
    if (randomTestimonial1) randomTestimonials.push(randomTestimonial1);
    if (randomTestimonial2) randomTestimonials.push(randomTestimonial2);

    const imageMap = {
        "images/course1.jpg": courseImage,     // Since all of the images are the same for featured courses only one image to place in this 
    };

    return (
        <main>
            <div>
                <h1 className="about"> About LMS: </h1>
                <p>
                    The Learning Management System, also known as LMS, is an application <br />
                    which allows students to explore courses, enroll in courses, and view testimonials. <br />
                    It is a system that makes things efficient for students.
                </p>
            </div>
            <div>
                <h1 className="key">Featured Courses</h1> <br/>
                <div>
                    {featuredCourses.map(course => (
                        <div key={course.id}>
                            <img src={imageMap[course.image]} alt={course.name} height="200" width="200" />
                            <h3>{course.name}</h3>
                            <p>
                                Description: {course.description} <br/>
                                Instructor: {course.instructor} <br/>
                                Duration: {course.duration}

                            </p>
                            
                        </div>
                    ))}
                <div>
                <h2>Testimonials</h2>
                {randomTestimonials.map((testimonial, index) => (
                    <div key={index}>
                        <p>{testimonial.studentName} - {testimonial.courseName}</p>
                        <p>{testimonial.review}</p>
                        <p className="testimonial"> {/*For the ratings print the stars*/}
                            {'★'.repeat(testimonial.rating)}
                            {'☆'.repeat(5 - testimonial.rating)}
                        </p>

                    </div>
                ))}
                </div>
                </div>
            </div>
        </main>
    );
}

export default MainSection;