import React, { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthMessage from './AuthMessage';
import '../components/styles.css'

const AuthContext = React.createContext();

function LoginForm() {
    const [username, setUsername] = useState('');   // State is set as empty first
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState(null);
    const [messageType, setMessageType] = useState(null);
    const [loginAttempt, setLoginAttempt] = useState(0);
    const navigate = useNavigate();

    /*This is how useEffect is rendered. When the login button or enter button is pressed, the loginAttempt value is 
    incremented. Since the loginAttempt variable is the dependency of useEffect, everytime it is incremented, the 
    useEffect works and applies its logic to fetch data from the API, check whether the username exists, then
    set the message and type accordingly. */

    const handleLogin = (e) => { 
        e.preventDefault();
        setLoginAttempt(loginAttempt + 1);
    };
  

    useEffect(() => {
        if (loginAttempt > 0) {
            async function performLogin() {
                if (!username || !password) {
                    setMessage('Username and password cannot be empty.');
                    setMessageType('error');
                    return;
                }

                if (password.length < 8) {
                    setMessage('Password must be at least 8 characters.');
                    setMessageType('error');
                    return;
                }

                try {
                    const response = await fetch('https://jsonplaceholder.typicode.com/users');
                    const users = await response.json();

                    const user = users.find((u) => u.username === username);

                    if (user) {
                        setMessage('Login successful! Redirecting to Coursepage...');
                        setMessageType('success');
                        setTimeout(() => {
                            navigate('/courses');
                        }, 2000);
                    } else {
                        setMessage('Invalid credentials. Please try again.');
                        setMessageType('error');
                    }
                } catch (error) {
                    setMessage('An error occurred. Please try again.');
                    setMessageType('error');
                }
            }
            performLogin();
        }
    }, [loginAttempt, navigate]);

    return (
        <AuthContext.Provider value={{ username, password, message, messageType }}>      {/* Using the useContext with these values to pass */}
            <div>
                <h2>Login</h2>
                <form onSubmit={handleLogin} className='form'>
                    <input
                        type="text"
                        placeholder="Username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}      // To set the variable created in useState (Event handling)
                    />
                    <p />
                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    <p />
                    <button type="submit" className="login-button">Login</button>
                </form>
                <br/><br/>
                <div className={`message-box ${message ? 'show-message' : ''}`}> {/* Since in the css, the box is initially hidden this displays the box after useEffect works its logic */}
                    <p />
                    <AuthMessage />     {/* Calling AuthMessage to display message */}
                </div>
                <br></br>
                <a href="#forgot" className="forgot-password">
                    Forgot Password
                </a> <br/><br/>
            </div>
        </AuthContext.Provider>
    );
}

export { LoginForm, AuthContext };