import React from 'react';
import { Link } from "react-router-dom";
import logo from '../images/logo.jpg';
import '../components/styles.css';

function Header() {
    return (
        <>
        <div className='header'>
            <img src={logo} alt="logo" height="150" width="150" />
        
        </div>
        <div>
            <nav className="nav">
                <ul>
                        <li>
                            <Link to="/">Home</Link>
                        </li>
                        <li>
                            <Link to="/courses">Courses</Link>
                        </li>
                        <li>
                            <Link to="/login">Login</Link>
                        </li>
                    </ul>
                </nav>

        </div>
        </>
            
        
    );
}

export default Header;