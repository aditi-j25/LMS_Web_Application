'''=== Group Info ===
Aamna Ghimire (30206981)
Aditi Jain (30208786)

'''

import os
import json
from flask import Flask, request, jsonify
from flask_cors import CORS
import random

app = Flask(__name__)
CORS(app)

# === Paths ===
BASE_DIR = os.path.dirname(__file__)
DATA_DIR = os.path.join(BASE_DIR, "data")
COURSES_PATH = os.path.join(DATA_DIR, "courses.json")
TESTIMONIALS_PATH = os.path.join(DATA_DIR, "testimonials.json")
STUDENTS_PATH = os.path.join(DATA_DIR, "students.json")

# === Load courses and testimonials ===
with open(COURSES_PATH) as f:
    all_courses = json.load(f)

with open(TESTIMONIALS_PATH) as f:
    all_testimonials = json.load(f)

# === Load or initialize students to append to ===
# Note: making a file students.json to show real time appends done by the backend accoring to interaction with user
if os.path.exists(STUDENTS_PATH):
    with open(STUDENTS_PATH) as f:
        students = json.load(f)
else:
    students = []

# Ensure next_student_id is 1 ahead of current student id
next_student_id = max([s["id"] for s in students], default=0) + 1

# === Save Students to students.json ===
def save_students():
    with open(STUDENTS_PATH, "w") as f:
        json.dump(students, f, indent=2)


# === Getters ===
def get_student_by_username(username):
    return next((s for s in students if s["username"] == username), None)

def get_student_by_id(student_id):
    return next((s for s in students if s["id"] == student_id), None)


# === 3) Testimonials API ===

@app.route("/testimonials", methods=["GET"])
def get_testimonials():
    return jsonify(random.sample(all_testimonials, 2)), 200

# === 4) Enroll Courses API === 

@app.route("/enroll/<int:student_id>", methods=["POST"])
def enroll_course(student_id):
    student = get_student_by_id(student_id)
    if not student:
        return jsonify({"message": "Student not found"}), 404

    course = request.get_json()
    already_enrolled = any(c["id"] == course["id"] for c in student["enrolled_courses"])
    if already_enrolled:
        return jsonify({"message": "Already enrolled"}), 400

    course["enrollmentId"] = f"{student_id}-{course['id']}"
    student["enrolled_courses"].append(course)
    save_students()
    return jsonify({"message": "Enrolled successfully"}), 200


# === 5) Enroll Courses API === 

@app.route("/drop/<int:student_id>", methods=["DELETE"])
def drop_course(student_id):
    student = get_student_by_id(student_id)
    if not student:
        return jsonify({"message": "Student not found"}), 404

    data = request.get_json()
    enrollment_id = data.get("enrollmentId")

    before = len(student["enrolled_courses"])
    student["enrolled_courses"] = [
        c for c in student["enrolled_courses"] if c.get("enrollmentId") != enrollment_id
    ]
    after = len(student["enrolled_courses"])

    if before == after:
        return jsonify({"message": "Enrollment not found"}), 404

    save_students()
    return jsonify({"message": "Course dropped"}), 200

# === 6) Get All Courses AP === 
@app.route("/courses", methods=["GET"])
def get_courses():
    return jsonify(all_courses), 200


# === 7) Get Student Courses API === 
@app.route("/student_courses/<int:student_id>", methods=["GET"])
def get_student_courses(student_id):
    student = get_student_by_id(student_id)
    return jsonify(student["enrolled_courses"] if student else []), 200


if __name__ == "__main__":
    app.run(debug=True)
